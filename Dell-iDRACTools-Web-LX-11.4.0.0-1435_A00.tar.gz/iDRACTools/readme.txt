The package that you downloaded contains the following tools:
• RACADM
• IPMI Tool

==========================================================================================
Release summary
==========================================================================================
The Integrated Dell Remote Access Controller (iDRAC) is designed to make server administrators
more productive and improve the overall availability of Dell servers.

iDRAC alerts administrators to server issues, helps them perform remote server management, and
reduces the need for physical access to the server. Additionally, iDRAC enables administrators
to deploy, monitor, manage, configure, update, and troubleshoot Dell servers from any location
without using any agents. It accomplishes this regardless of the operating system or hypervisor
presence or state.

iDRAC provides out-of-band mechanisms for configuring the server, applying firmware updates,
saving or restoring a system backup, or deploying an operating system, by using the iDRAC GUI, the
iDRAC RESTful API or the RACADM command line interface.

This release of the RACADM command line interface includes updated packaging supporting
the installation of both local and remote RACADM and fixes to issues documented below.

------------------------------------------------------------------------------------------
Version
------------------------------------------------------------------------------------------
Dell iDRAC Tool for Linux  v11.4.0.0

------------------------------------------------------------------------------------------
Release date
------------------------------------------------------------------------------------------
December 2025

==========================================================================================
Compatibility
==========================================================================================
For SLES 15 systems, the HAPI RPM has a dependency on the 'insserv-compact' OS package.
To ensure backward compatibility, HAPI still uses System V init scripts and has this
dependency. Install this package before installing RACADM.

==========================================================================================
New and enhanced features
==========================================================================================
RACADM:
. Support for RHEL 10 OS
. Support for SLES 15 SP7 OS
. Support for SLES 16 OS
. Support for UBUNTU 24.04


IPMI Tool:
• 	
• 

==========================================================================================
Fixes
==========================================================================================
RACADM:
   . 324902: Fixed an issue getting invalid file format error when using ".d10" file for fwupdate in remote racadm.
   . 330833: srvadmin-idrac readme file updated.
   
IPMI Tool:
   . 
   . 

==========================================================================================
Known issues
==========================================================================================
RACADM:
RAC1143 Error for RACADM Command
Description: The error RAC1143, which states "Configuration results are not applicable for Job type for Job <-j>," occurs while performing the command "racadm lclog viewconfigresult -j" without specifying a job and using the "--nocertwarn" option from the local RACADM interface.
Workaround: N/A
Tracking:  313793
	
Description: When OMSA is uninstalled using YUM, the local RACADM functionality becomes unavailable, resulting in an error message stating: "ERROR: Unable to perform requested operation."
Workaround: Reinstalling iDRACTools will restore local RACADM functionality.
Tracking: 329785

Description: Uninstalling iDRAC tools might appear successful, despite the tools may not actually be removed.
Workaround: Uninstall iDRACTools using the script
Tracking: 329977,329984

ARM based servers are not supported
Description: iDRACTools application is not supported on ARM based servers.
Workaround: N/A
Systems Affected: ARM based servers
Tracking: 363186

IPMI Tool:
 N/A


==========================================================================================
Installation
==========================================================================================
RACADM:
1. Navigate to the directory where the tar.gz  of iDRACTools is downloaded.
2. Run tar -zxvf on the tar.gz to unzip the contents into the current directory.
3. Inside the folder where you extracted the files, navigate to /linux/rac folder.
4. To install the RACADM binary, execute the script install_racadm.sh.
   
   Note: Open a new console window to run the RACADM commands. You cannot execute RACADM
   commands from the console window using which you executed the install_racadm.sh script. 
   
   If you get an SSL error message for remote RACADM, use the following steps to
   resolve the error:
   a. Run the command 'openssl version' to find the openssl version installed in the Host OS.
   b. Locate the openSSL libraries that are present in the HOST OS.
      Example: ls -l /usr/lib64/libssl*
   c. Soft-link the library libssl.so using ln -s command to the appropriate OpenSSL 
      version present in the Host OS.
      Example: ln -s /usr/lib64/libssl.so.<version> /usr/lib64/libssl.so

To uninstall RACADM, use the 'uninstall_racadm.sh' script.

Note:
• RACADM and its specific RPMS/Debians can be installed without requiring the installation of OMSA components.
• The installed RACADM binary can be used to execute both Local RACADM and Remote RACADM commands.
• The install_racadm.sh installs only the RPMS/Debians required for RACADM (srvadmin-argtable2, srvadmin-idracadm7, srvadmin-hapi).
• If the RPM's files are installed directly without the script, the path will not be set to the RPM files once the host is logged out leads to Racadm command failure.
• In case of UBUNTU installation, install_racadm.sh and uninstall_racadm.sh scripts has to run using bash as below:
  bash ./install_racadm.sh
  bash ./uninstall_racadm.sh
  $PATH information will differ between host and SSH login.

IPMI Tool:
To install the latest version of RAC Tools, do the following:
1 Uninstall the existing IPMI tool:
	a) Query the existing IPMI tool: rpm -qa | grep ipmitool
	   If the IPMI tool is already installed, the query returns ipmitool-x.x.xx-x.x.xx.
	b) To uninstall the IPMI tool:
	   On systems running SUSE Linux Enterprise Server  type rpm -e ipmitool-x.x.xx-x.x.xx
	   On systems running Red Hat Enterprise Linux 6.x, type rpm -e ipmitool
	   On systems running Red Hat Enterprise Linux 7.x, type rpm -e OpenIPMI-tools
2 Browse to the downloaded DRAC tools directory and got to IPMI tool sub folder and then
  type rpm -ivh ipmitool*.rpm
3 To update already available Dell IPMI Tool type rpm -Uvh ipmitool*.rpm

==========================================================================================
Resources and support
==========================================================================================
------------------------------------------------------------------------------------------
Accessing documents using direct links
------------------------------------------------------------------------------------------
You can directly access the documents using the following links:
• dell.com/idracmanuals		       —	    iDRAC and Lifecycle Controller
• dell.com/openmanagemanuals	    —	    Enterprise System Management
• dell.com/serviceabilitytools	 —	    Serviceability Tools
• dell.com/OMConnectionsClient	 —	    Client System Management
• dell.com/OMConnectionsClient	 —	    OpenManage Connections Client systems management 
• dell.com/OMConnectionsEnterpriseSystemsManagement — OpenManage Connections Enterprise
                                                      Systems Management

------------------------------------------------------------------------------------------
Accessing documents using product selector
------------------------------------------------------------------------------------------
You can also access documents by selecting your product.
1. Go to dell.com/manuals.
2. In the All products section, click Software --> Enterprise Systems Management.
3. Click the desired product and then click the desired version, if applicable.
4. Click Manuals & documents. 

==========================================================================================
Contacting Dell
==========================================================================================
Dell provides several online and telephone-based support and service options.
Availability varies by country and product, and some services may not be available in
your area. To contact Dell for sales, technical support, or customer service issues,
go to www.dell.com/contactdell.

If you do not have an active Internet connection, you can find contact information on
your purchase invoice, packing slip, bill, or the product catalog.

==========================================================================================
Information in this document is subject to change without notice.
Copyright © 2023-2025 Dell Inc. or its subsidiaries. All Rights Reserved.
Dell and other trademarks are trademarks of Dell Inc. or its subsidiaries.
Other trademarks may be trademarks of their respective owners.

Rev: A00